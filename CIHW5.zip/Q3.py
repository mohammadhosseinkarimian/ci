# Q3_graded
# Do not change the above line.
import numpy as np
import random as random


################## Fitness######################## 
def Fitness(we, valu, var, capacity):
    fit_val = np.empty(var.shape[0])
    shp = var.shape[0]
    for i in range(shp):
        sum1 = np.sum(var[i] * valu)
        sum2 = np.sum(var[i] * we)
        if sum2 > capacity:
            fit_val[i] = 0
        else:
            fit_val[i] = sum1
    return fit_val.astype(int)


we = np.array([2, 4, 1, 3, 5, 1, 7, 4])
valu = np.array([30, 10, 20, 50, 70, 15, 40, 25])
jewelry = np.array([0, 1, 2, 3, 4, 5, 6, 7])
capacity = 25
var = np.random.randint(2, size=(16, 8))
var = var.astype(int)
param = []
fitlist = []

for i in range(100):
    val_fit = Fitness(we, valu, var, capacity)
    fitlist.append(val_fit)
################## Selection ######################## 
    shpe = var.shape[1]
    father = np.empty((8, shpe ))
    list_fit = list(val_fit)
    for ii in range(8):
        maxfit = np.where(list_fit == np.max(list_fit))
        father[ii, :] = var[maxfit[0][0], :]
        list_fit[maxfit[0][0]] = -99
    parent = father
    par_shape0 = parent.shape[0]
    par_shape1 = parent.shape[1]

################## CrossOver ######################## 

    c_ind = 0
    cross_rate = 0.9
    point = int(par_shape1 / 2)
    result = np.empty((8, par_shape1))

    while (par_shape0 < 8):
        x = random.random()
        par1 = (c_ind + 1) % par_shape0
        par2 = c_ind % par_shape0

        if x > cross_rate:
            continue
        parent2 = c_ind % par_shape0
        parent1 = (c_ind + 1) % par_shape0
        result[c_ind, 0:point] = parent[parent2, 0:point]
        result[c_ind, point:] = parent[parent1, point:]
        c_ind = +1
################## Mutation ######################## 

    mutation_rate = 0.4
    mutation = np.empty((result.shape))
    mu_shape = mutation.shape[0]
    for ii in range(mu_shape):
        mutation[ii, :] = result[ii, :]
        val = random.random()
        if val > mutation_rate:
            continue
        res_shape = result.shape[1]
        val_rand = random.randint(0, res_shape - 1)
        if mutation[ii, val_rand] == 0:
            mutation[ii, val_rand] = 1
        else:
            mutation[ii, val_rand] = 0
            
    var[0:par_shape0, :] = parent
    var[par_shape0:, :] = mutation

val_fited = Fitness(we, valu, var, capacity)
fit_max = np.where(val_fited == np.max(val_fited))
################## OutPut ######################## 

param.append(var[fit_max[0][0], :])
print('The order of the jewelries in the chromosome is : Zomorod , Noghre , Yaghoot , Almas , Berelyan , Firooze , Atigh , Kahroba')
final_answer = (jewelry + 1) * param
array = ['Zomorod', 'Noghre', 'Yaghoot', 'Almas', 'Berelyan', 'Firooze', 'Atigh', 'Kahroba']
print('These jewelries are selected:')
for i in range(final_answer.shape[1]):
    if final_answer[0][i] != 0:
        print(array[i])
print('Result :'+ format(param))



