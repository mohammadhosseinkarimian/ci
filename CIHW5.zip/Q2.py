# Q2_graded
# Do not change the above line.
import numpy as np
import random

########################## Selection #####################################
values=[]
value_list = []
random.seed(100)
chromosomes=[[random.randint(0,9) for i in range(8)] for j in range(2)]
for generation in range(100): # number of generations = 100
  generation+=1
  slct = []
  for chromosome in chromosomes:
    x = 2 * chromosome[0] * chromosome[0]
     ###########Fitness###########
    chrm =  abs(59 - ( x + chromosome[1]))
    slct.append(chrm)
  slcted = list(zip(slct, chromosomes))
  slcted.sort(reverse=True)

  for ch in slcted:
    if ch[0] == 0:
      if ch[1] not in values:
        values.append(ch[1])

  slcted = slcted[:4]
  sde, chromosomes = zip(*slcted)
  chromosomes = list(chromosomes)

  ########################## CrossOver part#####################################
  random.shuffle(chromosomes)
  first=chromosomes[:1]
  second=chromosomes[1:]
  crossovers=[]
  for i in range(len(first)):
    crossover= 4
    firstpart=[first[i][:crossover],first[i][crossover:]]
    secondpart=[second[i][:crossover],second[i][crossover:]]
    first_crossover=firstpart[0]+secondpart[1]
    crossovers.append(first_crossover)
    second_crossover=secondpart[0]+firstpart[1]
    crossovers.append(second_crossover)
  chromosomes += crossovers

  ########################## Mutation part #####################################
  most_fitted=[]
  for i in chromosomes:
    ind=random.randint(0,7)
    i[ind]=random.randint(0,9)
    most_fitted.append(i)
  chromosomes += most_fitted
for value in values:
  value_list.append([value[0], value[1]])
#print(value_list)
counter = 0
num = value_list[0]

########################## Finding the most fitted part#####################################
for i in value_list:
  curr_frequency = value_list.count(i)
  if(curr_frequency> counter):
    counter = curr_frequency
    num = i
print(num)
print("x = "+str(num[0]) + " And y = " + str(num[1]))


