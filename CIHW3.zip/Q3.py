# Q3_graded
# Do not change the above line.

from PIL import Image
import numpy as np
import urllib.request
import matplotlib.pyplot as plt


urllib.request.urlretrieve(
  'https://user-images.githubusercontent.com/47971866/143790821-ee9242e8-ce51-4325-a5b4-a2a7de804ef0.jpg',
   "train1.jpg")
urllib.request.urlretrieve('https://user-images.githubusercontent.com/47971866/143790831-508d1226-bc56-4864-9517-440a0050b21e.jpg' , "train2.jpg")
urllib.request.urlretrieve('https://user-images.githubusercontent.com/47971866/143790833-03685c79-b3a0-4680-adcb-a2b66ef8ded8.jpg' , "train3.jpg")
urllib.request.urlretrieve('https://user-images.githubusercontent.com/47971866/143790834-c827e5e5-793f-4cd5-9612-e54b113782e5.png' , "train4.jpg")


urllib.request.urlretrieve('https://user-images.githubusercontent.com/47971866/143790861-b8e911f2-9653-457b-b1ff-e842677e4694.jpg' , "test1.jpg")
urllib.request.urlretrieve('https://user-images.githubusercontent.com/47971866/143790863-ba812fe0-024e-47f0-8e46-aab12938c68c.jpg' , "test2.jpg")
urllib.request.urlretrieve('https://user-images.githubusercontent.com/47971866/143790864-f4308bc4-b776-4494-b024-312d9e2964ee.jpg' , "test3.jpg")
urllib.request.urlretrieve('https://user-images.githubusercontent.com/47971866/143790865-f717eae8-5a34-41de-b42d-bb25da0efa2a.png' , "test4.jpg")

  
t1 = Image.open("train1.jpg").convert('L')
t2 = Image.open("train2.jpg").convert('L')
t3 = Image.open("train3.jpg").convert('L')
t4 = Image.open("train4.jpg").convert('L')
t5 = Image.open("test1.jpg").convert('L')
t6 = Image.open("test2.jpg").convert('L')
t7 = Image.open("test3.jpg").convert('L')
t8 = Image.open("test4.jpg").convert('L')

#train1 = np.array(t1)
#train2 = np.array(t2)
#train3 = np.array(t3)
#train4 = np.stack((np.array(t4),)*3, axis=-1)
train_list =[]
train_list.append(t1)
train_list.append(t2)
train_list.append(t3)
train_list.append(t4)
tests = []
tests.append(t5)
tests.append(t6)
tests.append(t7)
tests.append(t8)

class HopfieldNet:

    def __init__(self, n):
        self.n = n
        self.weights = np.zeros((n, n))

    def train(self, input):
        
        p = np.dot(input.T, input)
        
        np.fill_diagonal(p, 0)
        
        self.weights += p
        #print(self.weights.shape)
        #print(self.weights[0])
    
    def restore(self, x):
        p = np.sum(x * self.weights, axis=1)
        return np.array(np.sign(p.T))

    def update(self, input):
        current_x = input
        last_x = np.copy(current_x)
        for i in range(1000):
            current_x = self.restore(current_x)
            if np.array_equal(current_x, last_x):
                break
            last_x = np.copy(current_x)
        return current_x
dim = 100

def generate_patterns(f):

    patterns = []
    img = f
    img = img.resize((dim, dim))
    img_arr = np.asarray(img, dtype=np.uint8)

    pattern = np.ones(img_arr.shape)
    pattern[img_arr <= 60] = -1

    patterns.append(pattern.flatten())
    return np.array(patterns)



for f in train_list:
    patterns = generate_patterns(f)
    #print(patterns)
    #print("*****")
    hn = HopfieldNet(dim ** 2)
    hn.train(patterns)
    final =0
    error =0
    for ind in range(4):
      img = tests[ind]
      img = img.resize((dim, dim))
      img_arr = np.asarray(img, dtype=np.uint8)

      pattern = np.ones(img_arr.shape)
      pattern[img_arr <= 60] = -1

      result_pattern = hn.update(pattern.flatten())

      result_arr = np.where(result_pattern >= 0, 255, 0)
      result_arr = np.array(result_arr, dtype=np.uint8)

      out = Image.fromarray(result_arr.reshape((dim, dim)))
      out = np.stack((np.array(out),)*3, axis=-1)
      final = out

      org_img = train_list[ind]
      org_img = org_img.resize((dim, dim))
      org_img_arr = np.asarray(org_img, dtype=np.uint8)

      org_img_pattern = np.ones(org_img_arr.shape)
      org_img_pattern[org_img_arr <= 60] = -1
      org_img_pattern = org_img_pattern.flatten()

      rate = 100 - 100 * np.sum(np.abs(result_pattern - org_img_pattern)) / (2 * dim * dim)
      error += rate/2
      print(f'Accuracy for comparing with training image number {str(ind+1)} --> {str(rate)}')
    plt.imshow(final)
    plt.show()
    error = (error - 100)/3
    print(f'Error  --> {str(error)}')
    print("*************************************************************")

    

