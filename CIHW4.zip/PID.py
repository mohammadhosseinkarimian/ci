import time
import numpy as np
import skfuzzy as fuzz
from skfuzzy import control as ctrl


class PID:
    def __init__(
        self,
    ):

        self.clear()

    def clear(self):
        """
        initialize and set fuzzy term and rules
        """
        self.pos = ctrl.Antecedent(np.arange(-1.3, 0.7, 0.01), "pos")
        self.v = ctrl.Antecedent(np.arange(-0.8, 0.09, 0.001), "velocity")

        self.out = ctrl.Consequent(np.arange(-1.1, 1.1, 0.01), "out")


        self.pos["very_low"] = fuzz.trimf(self.pos.universe, [-1.3, -1.1, -0.7])

        self.pos["low"] = fuzz.trimf(self.pos.universe, [-1.1, -0.7, 0.4])
        self.pos["mid"] = fuzz.trimf(self.pos.universe, [-0.5, -0.1, 0.5])
        self.pos["high"] = fuzz.trimf(self.pos.universe, [0.3, 0.45, 0.6])
        self.pos["very_high"] = fuzz.trimf(self.pos.universe, [0.5, 0.7, 0.8])


        self.v["very_low"] = fuzz.trimf(self.v.universe, [-0.7, -0.2, -0.1])

        self.v["low"] = fuzz.trimf(self.v.universe, [-0.2, -0.1, 0])

        self.v["none"] = fuzz.trimf(self.v.universe, [-0.1, 0, 0.05])
        self.v["high"] = fuzz.trimf(self.v.universe, [0, 0.05, 0.1])

        self.out["very_low"] = fuzz.trimf(self.out.universe, [-1.1, -1, -0.9])

        self.out["low"] = fuzz.trimf(self.out.universe, [-1, -0.5, -0.3])
        self.out["mid"] = fuzz.trimf(self.out.universe, [-0.5, 0, 0.6])
        self.out["high"] = fuzz.trimf(self.out.universe, [0.4, 0.8, 1])
        self.out["very_high"] = fuzz.trimf(self.out.universe, [0.9, 1, 1.1])

        rule1 = ctrl.Rule(self.pos["low"] & self.v["low"], self.out["low"])
        rule2 = ctrl.Rule(self.pos["low"] & self.v["very_low"], self.out["high"])
        rule3 = ctrl.Rule(self.pos["low"] & self.v["none"], self.out["mid"])
        rule4 = ctrl.Rule(self.pos["low"] & self.v["high"], self.out["very_high"])

        rule5 = ctrl.Rule(self.pos["mid"] & self.v["very_low"], self.out["high"])
        rule6 = ctrl.Rule(self.pos["mid"] & self.v["low"], self.out["low"])
        rule7 = ctrl.Rule(self.pos["mid"] & self.v["none"], self.out["low"])
        rule8 = ctrl.Rule(self.pos["mid"] & self.v["high"], self.out["high"])


        rule9 = ctrl.Rule(self.pos["high"]& self.v["high"] , self.out["mid"])
        rule10 = ctrl.Rule(self.pos["high"] & self.v["none"], self.out["low"])
        rule11 = ctrl.Rule(self.pos["high"] & self.v["low"], self.out["very_low"])
        rule12 = ctrl.Rule(self.pos["high"] & self.v["very_low"], self.out["low"])

        rule13 = ctrl.Rule(self.pos["very_low"], self.out["very_high"])
        rule14 = ctrl.Rule(self.pos["very_high"]& self.v["high"], self.out["very_low"])
        rule15 = ctrl.Rule(self.pos["very_high"]& self.v["none"], self.out["low"])

        self.force_ctrl = ctrl.ControlSystem([rule1, rule2, rule3, rule4, rule5,rule6, rule7, rule8, rule9, rule10, rule11, rule12, rule13, rule14, rule15])
        self.ctrl_sim = ctrl.ControlSystemSimulation(self.force_ctrl)

        self.output = 0.0

    def update(self, feedback_value):
        """
        update self.output
        """
        self.ctrl_sim.input["pos"] = feedback_value[0]
        self.ctrl_sim.input["velocity"] = feedback_value[1]
        self.ctrl_sim.compute()

        print("after fuzzy : {} ".format(self.ctrl_sim.output["out"]))
        self.output = self.ctrl_sim.output["out"]
