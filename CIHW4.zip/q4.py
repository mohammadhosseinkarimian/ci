NUMBER_OF_EXAMPLES = 1
HORIZON = 700
ENV_NAME = "MountainCarContinuous-v0"

import os
import sys

lib_path = os.path.abspath(os.path.join(sys.path[0], ".."))
sys.path.append(lib_path)
import gym
import matplotlib.pyplot as plt
from PID import *
import math

Ctl = PID()

graph = []

env = gym.make(ENV_NAME)

for i_episode in range(NUMBER_OF_EXAMPLES):
    observation = env.reset()
    # start sim
    for t in range(HORIZON):
        env.render()
        print(observation)
        feedback = env.state
        graph.append(feedback[0])
        print("f is : ", feedback)
        Ctl.update(feedback)
        action = [Ctl.output]
        print("action ", action)
        observation, reward, done, info = env.step(action)
env.close()
