# Q1_graded
# Do not change the above line.

def predict(x,w,b):
  pr = 1/(1+np.exp(-(np.dot(x,w)+b)))
  pr[pr>0.5]=1
  pr[pr<=0.5]=0
  return pr


def GD(Epochs,sgd,learning_rate):
  epoch=Epochs
  n = X.shape[1]
  #l = 0.01 the best learning rate
  l=learning_rate
  b = 0
  w = np.array([0.15,0.11])
  loss = []
  for i in range(0,epoch):
    if (not sgd):
      if(i>(1/l)):
        l = 0.001*(1/i)
      sigma=np.dot(X.T,w)+b
      d = 1/(1+np.exp(-sigma))
      lll =-np.mean(Y*(np.log(d)) - (1-Y)*np.log(1-d))
      loss.append(lll)
      deltaw = (np.dot(X,(d-Y[0])))/400
      deltab = (np.sum(d-Y)/400)
      if i % 100 == 0:
        print("cost of %i: %f" % (i, lll))
    else:
      ind = np.random.randint(0, len(X)) # random point
      chosen = X.T[ind]
      f=Y[0][ind]-np.dot(chosen,w)
      deltaw = np.dot(chosen,f)
      deltab = f
    w -= l*deltaw
    b -= l*deltab
    pl = predict(X.T,w,b)
    accuracy = np.sum(Y[0] == pl) / len(Y[0])
    if i % 100 == 0:
      print("accuracy of %i: %f" % (i, accuracy))

  
  plot_decision_boundary(lambda x: predict(x,w,b), X, Y)
  plt.title("Decision Boundry")

GD(1000,True,0.01) #calling Gradient Descent function

