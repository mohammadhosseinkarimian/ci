# Q3_graded
# Do not change the above line.
import tensorflow as tf
from tensorflow import keras
from keras import regularizers
from keras.layers import Dense, Flatten

(x_train, y_train), (x_test, y_test) =keras.datasets.fashion_mnist.load_data()
x_train = x_train / 255.0
x_test = x_test / 255.0
keras.optimizers.SGD(
   learning_rate=0.01, momentum=1, nesterov=False, name="SGD"
)

model = keras.Sequential([Flatten(input_shape=(28, 28)),
    Dense(100, activation=tf.nn.tanh),
    Dense(10, activation=tf.nn.softmax)
])

model.compile(optimizer='adam',loss='sparse_categorical_crossentropy', metrics=['accuracy'])
model.fit(x_train, y_train, epochs=10)

# https://www.tensorflow.org/api_docs/python/tf/keras/datasets/fashion_mnist/load_data



