# Q2.1_graded
# Do not change the above line.

import numpy as np
import keras
from keras import backend as bc
from keras.layers import Layer

from matplotlib import pyplot as plt

#input dots on the given image
train_x = np.array([[0.5,0.5], [0.6,0.5], [0.4,0.6], [0.5,0.6],[0.4,0.4], [0.5,0.4], [0.6,0.4], [0.4,0.5], [0.6,0.6], [0.15, 0.25],[0.2, 0.4], [0.2,0.5], [0.2,0.6], [0.3,0.3], [0.4,0.3],
                    [0.6,0.3], [0.7,0.3], [0.8, 0.4], [0.8,0.5], [0.8,0.6],[0.3, 0.4], [0.3,0.5], [0.3,0.6], [0.7, 0.4],[0.4,0.7], [0.5,0.7], [0.6,0.7], [0.7,0.5], [0.7,0.6]])
train_y = np.array([0,0,0,0,0,0,0,0,0,3,2,2,2,2,2,2,2,2,2,2,1,1,1,1,1,1,1,1,1])
tempone = np.random.uniform(0.1, 0.8, 30)
temptwo = np.random.uniform(0.1, 0.9, 30)
test_x = np.zeros((30,2))
test_x[:,0] = tempone
test_x[:,1] = temptwo

plt.scatter(train_x[:, 0], train_x[:, 1], c=train_y, cmap='plasma')
plt.grid()
plt.xlim(0, 1)
plt.ylim(0, 1)
plt.title('***Datas Of Training***')
plt.show()


#30 random numbers plus ourinput dotsfrom the training should be in testing part as it is said in the question

test_y = []
for i in range(0,30):
  test_y.append(3)

test_y = np.concatenate((test_y, train_y), axis=0)

test_x = np.concatenate((test_x, train_x), axis=0)

plt.scatter(test_x[:, 0], test_x[:, 1], c=test_y , cmap='plasma')
plt.grid()
plt.xlim(0, 1)
plt.ylim(0, 1)
plt.title('***Datas Of Training Before RBF***')
plt.show()

class RBF_Layer(Layer):
    def __init__(self, inps, phi, **kwargs):
        super(RBF_Layer, self).__init__(**kwargs)
        self.phi = bc.cast_to_floatx(phi)
        self.inps = inps
    def compute_output_shape(self, shape):
        return (shape[0], self.inps)
    def build(self, shape):
        self.m = self.add_weight(name='mu',shape=(int(shape[1]), self.inps),initializer='uniform',trainable=True)
        super(RBF_Layer, self).build(shape)
    def call(self, inputs):
        res = bc.exp(-1 * self.phi * bc.sum(bc.pow(bc.expand_dims(inputs) - self.m, 2), axis=1))
        return res


model = keras.models.Sequential(layers=[keras.layers.Input(2),
                                        RBF_Layer(17, 0.5),
                                        keras.layers.Dense(4, activation='softmax'),
])

model.compile(optimizer = 'adam',loss = 'sparse_categorical_crossentropy',metrics = ['accuracy'])
hist = model.fit(
    train_x,
    train_y,
    epochs = 18000,
    verbose = 0
)
y_r = np.argmax(model.predict(test_x), axis=1)

plt.scatter(test_x[:, 0], test_x[:, 1], c=y_r, cmap='plasma')
plt.grid()
plt.xlim(0, 1)
plt.ylim(0, 1)
plt.title('***Datas Of Training After RBF***')
plt.show()

plt.plot(hist.history['loss'])
plt.title('***Loss***')
plt.show()
plt.plot(hist.history['accuracy'])
plt.title('***Accuracy***')
plt.show()


