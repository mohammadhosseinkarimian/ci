# Q1_graded
# Do not change the above line.

from PIL import Image
import numpy as np
import urllib.request
import matplotlib.pyplot as plt #Used in the comparison below

urllib.request.urlretrieve(
  'https://raw.githubusercontent.com/mohammadhosseinkarimian/ci/main/input.jpg',
   "input.jpg")
  
im = Image.open("input.jpg")
neurons = 64*64
size = 64
learning_rate = 0.2
sigma = 16
epochs = 500

pic = np.array(im)



plt.imshow(pic)
plt.show()
im.close()
weights = np.zeros((neurons, 3)) 
weights += 255
#weights = np.random.rand(neurons)
#weights[weights>0.5] = 1
#weights[weights<0.5] = 0 
#weights = weights.reshape((neurons, 1))
inputs = pic.reshape(neurons,3)
ss=[]

#print(pic)
#print(pic.shape)
#pic = pic.reshape(64,64)
#plt.imshow(pic,cmap=matplotlib.cm.Greys_r)
#plt.show()

length = 1024
length_sqrt = int(np.sqrt(length))
def find_dists(a, index):
    i,j = np.indices(a.shape, sparse=True)
    return (i-index[0])**2 + (j-index[1])**2

def convert_reshape(a):
    a0 = (int) (a/length_sqrt)
    a1 = a % length_sqrt
    return a0, a1


for e in range(epochs):
  index = np.random.choice(neurons, length, replace=False)
  rand_inputs=inputs[index]
  rand_weights=weights[index]
  learning_rate *= 0.95
  for x in range(length):
      # find best neuron 
      arg_bmu = np.argmin(np.sum(np.square(np.subtract(rand_weights[x], rand_inputs[x]))))
        
      # find dist vector from all neurons to bmu
      dist = find_dists(np.zeros((length_sqrt,length_sqrt)), tuple(convert_reshape(arg_bmu))).reshape(-1,1)
      # update weights
      rand_weights += np.multiply(rand_inputs - rand_weights, np.exp((-dist)/(2*(sigma)**2)))*learning_rate
      weights[index]=rand_weights


# show results (by weights)
weights = weights.reshape(size,size,3)
plt.imshow(weights)
plt.show()


#print(inputs)
#plt.imshow(inputs.reshape(size,size,3))
#plt.show()



